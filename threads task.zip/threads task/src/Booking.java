public class Booking implements Runnable {
    private ticketbooking ticketBookings;

    private String customerName;

    private int ticketsRequested;

    public Booking(ticketbooking ticketBookings, String customerName, int ticketsRequested) {
        this.ticketBookings = ticketBookings;
        this.customerName = customerName;
        this.ticketsRequested = ticketsRequested;


    }

    @Override
    public void run(){ticketBookings.bookTicket(customerName, ticketsRequested);}
}