//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {
        ticketbooking ticketBookings = new ticketbooking();

        // Create thread for each user trying to book tickets
        Thread user1 = new Thread(new Booking(ticketBookings, "Trish Gumbo", 7));
        Thread user2 = new Thread(new Booking(ticketBookings, "Audrey", 4));
        Thread user3 = new Thread(new Booking(ticketBookings, "Brendan Gobvu", 8));

        // Start all threads
        user1.start();
        user2.start();
        user3.start();

    }
}