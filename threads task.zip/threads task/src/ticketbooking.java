public class ticketbooking {
    private int totalTickets = 10;

    public synchronized void bookTicket( String customerName, int ticketsRequested){
        if (ticketsRequested <= totalTickets) {
            totalTickets -= ticketsRequested;
            System.out.println(customerName + " successfully booked " + ticketsRequested + " ticket(s). Tickets remaining: " + totalTickets);
        } else {
            System.out.println(customerName + " failed to book " + ticketsRequested + " ticket(s). Not enough tickets available.");
    }   }
}
